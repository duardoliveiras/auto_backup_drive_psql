--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bicimoto;
--
-- Name: bicimoto; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bicimoto WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE bicimoto OWNER TO postgres;

\connect bicimoto

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    cd_cliente integer NOT NULL,
    nm_cliente character varying(100) NOT NULL,
    ds_telefone character varying NOT NULL,
    dt_nascimento date,
    ds_cpf character varying NOT NULL,
    ds_email character varying(100),
    ds_cep character varying,
    ds_endereco character varying(100) NOT NULL,
    ds_cidade character varying(100) NOT NULL,
    ds_bairro character varying(100) NOT NULL,
    ds_estado character varying(2) NOT NULL
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_cd_cliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_cd_cliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cliente_cd_cliente_seq OWNER TO postgres;

--
-- Name: cliente_cd_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_cd_cliente_seq OWNED BY public.cliente.cd_cliente;


--
-- Name: fornecedor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fornecedor (
    cd_fornecedor integer NOT NULL,
    nm_fornecedor character varying(100) NOT NULL,
    ds_telefone character varying NOT NULL,
    ds_endereco character varying(100),
    ds_cnpj character varying NOT NULL,
    ds_email character varying(100),
    ds_cep character varying,
    ds_cidade character varying(100),
    ds_estado character varying,
    ds_bairro character varying(100)
);


ALTER TABLE public.fornecedor OWNER TO postgres;

--
-- Name: fornecedor_cd_fornecedor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fornecedor_cd_fornecedor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fornecedor_cd_fornecedor_seq OWNER TO postgres;

--
-- Name: fornecedor_cd_fornecedor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fornecedor_cd_fornecedor_seq OWNED BY public.fornecedor.cd_fornecedor;


--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    cd_produto integer NOT NULL,
    nm_produto character varying(100) NOT NULL,
    ds_produto character varying(100) NOT NULL,
    vl_inicial numeric(10,2) NOT NULL,
    vl_final numeric(10,2) NOT NULL,
    qt_produto integer NOT NULL,
    cd_fornecedor integer NOT NULL,
    dt_atualizacao date
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: produto_cd_produto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_cd_produto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_cd_produto_seq OWNER TO postgres;

--
-- Name: produto_cd_produto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_cd_produto_seq OWNED BY public.produto.cd_produto;


--
-- Name: venda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venda (
    cd_venda integer NOT NULL,
    cd_cliente integer NOT NULL,
    dt_venda date NOT NULL,
    vl_total numeric(10,2) NOT NULL,
    ds_pagamento character varying(50),
    ds_observacao character varying(255)
);


ALTER TABLE public.venda OWNER TO postgres;

--
-- Name: venda_cd_venda_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.venda_cd_venda_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.venda_cd_venda_seq OWNER TO postgres;

--
-- Name: venda_cd_venda_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.venda_cd_venda_seq OWNED BY public.venda.cd_venda;


--
-- Name: venda_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venda_item (
    cd_item integer NOT NULL,
    qt_produto integer NOT NULL,
    vl_subtotal numeric(10,2) NOT NULL,
    cd_produto integer NOT NULL,
    cd_venda integer NOT NULL
);


ALTER TABLE public.venda_item OWNER TO postgres;

--
-- Name: venda_item_cd_item_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.venda_item_cd_item_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.venda_item_cd_item_seq OWNER TO postgres;

--
-- Name: venda_item_cd_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.venda_item_cd_item_seq OWNED BY public.venda_item.cd_item;


--
-- Name: cliente cd_cliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN cd_cliente SET DEFAULT nextval('public.cliente_cd_cliente_seq'::regclass);


--
-- Name: fornecedor cd_fornecedor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fornecedor ALTER COLUMN cd_fornecedor SET DEFAULT nextval('public.fornecedor_cd_fornecedor_seq'::regclass);


--
-- Name: produto cd_produto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN cd_produto SET DEFAULT nextval('public.produto_cd_produto_seq'::regclass);


--
-- Name: venda cd_venda; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venda ALTER COLUMN cd_venda SET DEFAULT nextval('public.venda_cd_venda_seq'::regclass);


--
-- Name: venda_item cd_item; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venda_item ALTER COLUMN cd_item SET DEFAULT nextval('public.venda_item_cd_item_seq'::regclass);


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (cd_cliente, nm_cliente, ds_telefone, dt_nascimento, ds_cpf, ds_email, ds_cep, ds_endereco, ds_cidade, ds_bairro, ds_estado) FROM stdin;
\.
COPY public.cliente (cd_cliente, nm_cliente, ds_telefone, dt_nascimento, ds_cpf, ds_email, ds_cep, ds_endereco, ds_cidade, ds_bairro, ds_estado) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: fornecedor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fornecedor (cd_fornecedor, nm_fornecedor, ds_telefone, ds_endereco, ds_cnpj, ds_email, ds_cep, ds_cidade, ds_estado, ds_bairro) FROM stdin;
\.
COPY public.fornecedor (cd_fornecedor, nm_fornecedor, ds_telefone, ds_endereco, ds_cnpj, ds_email, ds_cep, ds_cidade, ds_estado, ds_bairro) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produto (cd_produto, nm_produto, ds_produto, vl_inicial, vl_final, qt_produto, cd_fornecedor, dt_atualizacao) FROM stdin;
\.
COPY public.produto (cd_produto, nm_produto, ds_produto, vl_inicial, vl_final, qt_produto, cd_fornecedor, dt_atualizacao) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: venda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venda (cd_venda, cd_cliente, dt_venda, vl_total, ds_pagamento, ds_observacao) FROM stdin;
\.
COPY public.venda (cd_venda, cd_cliente, dt_venda, vl_total, ds_pagamento, ds_observacao) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: venda_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venda_item (cd_item, qt_produto, vl_subtotal, cd_produto, cd_venda) FROM stdin;
\.
COPY public.venda_item (cd_item, qt_produto, vl_subtotal, cd_produto, cd_venda) FROM '$$PATH$$/3362.dat';

--
-- Name: cliente_cd_cliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_cd_cliente_seq', 121, true);


--
-- Name: fornecedor_cd_fornecedor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fornecedor_cd_fornecedor_seq', 17, true);


--
-- Name: produto_cd_produto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_cd_produto_seq', 30, true);


--
-- Name: venda_cd_venda_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.venda_cd_venda_seq', 23, true);


--
-- Name: venda_item_cd_item_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.venda_item_cd_item_seq', 21, true);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (cd_cliente);


--
-- Name: fornecedor fornecedor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fornecedor
    ADD CONSTRAINT fornecedor_pkey PRIMARY KEY (cd_fornecedor);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (cd_produto);


--
-- Name: venda_item venda_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venda_item
    ADD CONSTRAINT venda_item_pkey PRIMARY KEY (cd_item);


--
-- Name: venda venda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venda
    ADD CONSTRAINT venda_pkey PRIMARY KEY (cd_venda);


--
-- Name: produto produto_cd_fornecedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_cd_fornecedor_fkey FOREIGN KEY (cd_fornecedor) REFERENCES public.fornecedor(cd_fornecedor);


--
-- Name: venda venda_cd_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venda
    ADD CONSTRAINT venda_cd_cliente_fkey FOREIGN KEY (cd_cliente) REFERENCES public.cliente(cd_cliente);


--
-- Name: venda_item venda_item_cd_produto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venda_item
    ADD CONSTRAINT venda_item_cd_produto_fkey FOREIGN KEY (cd_produto) REFERENCES public.produto(cd_produto);


--
-- Name: venda_item venda_item_cd_venda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venda_item
    ADD CONSTRAINT venda_item_cd_venda_fkey FOREIGN KEY (cd_venda) REFERENCES public.venda(cd_venda);


--
-- PostgreSQL database dump complete
--

